using System;

	/// <summary>
	/// Summary description for Turkey.
	/// </summary>
	public interface Turkey
	{
		string Gobble();
		string Fly();
	}
