using System;

	/// <summary>
	/// Summary description for ICheese.
	/// </summary>
	public interface ICheese 
	{
		string toString();
	}
