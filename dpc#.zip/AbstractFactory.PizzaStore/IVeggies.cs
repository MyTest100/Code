using System;

	/// <summary>
	/// Summary description for IVeggies.
	/// </summary>
	public interface IVeggies 
	{
		string toString();
	}
