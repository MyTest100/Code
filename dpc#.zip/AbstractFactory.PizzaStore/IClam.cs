using System;

	/// <summary>
	/// Summary description for IClams.
	/// </summary>
	public interface IClams
	{
		string toString();
	}
