using System;

	/// <summary>
	/// Summary description for ISauce.
	/// </summary>
	public interface ISauce 
	{
		 string toString();
	}
