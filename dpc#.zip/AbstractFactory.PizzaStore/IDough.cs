using System;

	/// <summary>
	/// Summary description for IDough.
	/// </summary>
	public interface IDough 
	{
		string toString();
	}
