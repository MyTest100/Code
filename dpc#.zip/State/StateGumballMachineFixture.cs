using System;
using System.Text;
	public class StateGumballMachineFixture
	{
		
		public static void Main()
		{
            //Test1();
            Test2();
        }

        public static void Test1() {
			StringBuilder gumballMachineOutput = new StringBuilder();
			
			GumballMachineStart gumballMachine = new GumballMachineStart(5);
			
			 
			gumballMachineOutput.Append(gumballMachine.MachineState() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");

			gumballMachineOutput.Append(gumballMachine.MachineState() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.EjectQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");

			gumballMachineOutput.Append(gumballMachine.MachineState() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");
			gumballMachineOutput.Append(gumballMachine.EjectQuarter() + "\n");

			gumballMachineOutput.Append(gumballMachine.MachineState() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");
			gumballMachineOutput.Append(gumballMachine.InsertQuarter() + "\n");
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");

			gumballMachineOutput.Append(gumballMachine.MachineState() + "\n");

            //Console.WriteLine("String to match {0}", stringToMatch.ToString());
            Console.WriteLine("The Transaction    {0}", gumballMachine.ToString());
			
		}
		
		public static void Test2()
		{
			GumballMachine gumballMachine = new GumballMachine(5);
			StringBuilder gumballMachineOutput = new StringBuilder();

			gumballMachineOutput.Append(gumballMachine.MachineStateHeader() + "\n");

			gumballMachineOutput.Append(gumballMachine.InsertQuarter());
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");

			gumballMachineOutput.Append(gumballMachine.MachineStateHeader() + "\n");

			gumballMachineOutput.Append(gumballMachine.InsertQuarter());
			gumballMachineOutput.Append(gumballMachine.TurnCrank());
			gumballMachineOutput.Append(gumballMachine.InsertQuarter());
			gumballMachineOutput.Append(gumballMachine.TurnCrank() + "\n");
			gumballMachineOutput.Append(gumballMachine.MachineStateHeader() + "\n");
			gumballMachineOutput.Append(gumballMachine.Refill(5) + "\n");			
			gumballMachineOutput.Append(gumballMachine.MachineStateHeader() + "\n");


			
			Console.WriteLine(gumballMachineOutput.ToString());
		}
		
	}

