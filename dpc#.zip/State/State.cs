using System;

	public interface State
	{
		string InsertQuarter();
		string EjectQuarter();
		string TurnCrank();
		string Dispense();
	}

